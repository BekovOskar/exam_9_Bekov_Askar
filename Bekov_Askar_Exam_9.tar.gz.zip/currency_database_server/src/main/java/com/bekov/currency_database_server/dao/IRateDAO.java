package com.bekov.currency_database_server.dao;

public interface IRateDAO {

    void deleteDate(String date);
    void deleteAll();
}
